"""Harmless installed-wheel fixture: authenticated loopback, events and cleanup."""
from __future__ import annotations

import asyncio
import json
import os
import sys
import tempfile
from pathlib import Path

from .contracts import WorkerLaunch, WorkerLaunchRequest, WorkerRequest
from .storage import PrivateStore, RuntimeStore, SQLiteStorage
from .supervisor import RuntimeSupervisor


class FixtureDriver:
    def prepare(self, request: WorkerLaunchRequest) -> WorkerLaunch:
        # No product profile, credentials, remote executable or sibling import path.
        return WorkerLaunch(
            (sys.executable, "-m", "locus_runtime.standalone", "--worker", "--port", str(request.port)),
            {"PATH": os.environ.get("PATH", ""), "FIXTURE_TOKEN": request.token},
            cwd=request.workspace, headers={"Authorization": "Bearer " + request.token})

    def command_request(self, command: dict) -> WorkerRequest | None:
        return None


def public_fixture_event(event: dict) -> dict:
    # Deliberately restricted public schema; an embedding host must supply its
    # own sanitizer for its protocol and private native payloads.
    return {key: value for key, value in event.items()
            if key in {"type", "text", "request_id", "message", "reason"}}


async def demo() -> dict:
    with tempfile.TemporaryDirectory(prefix="locus-runtime-demo-") as directory:
        root = Path(directory)
        storage = SQLiteStorage(root / "runtime.sqlite3")
        runtime = RuntimeSupervisor(root, store=RuntimeStore(storage.connect, sanitize=public_fixture_event),
                                    private=PrivateStore(root), driver=FixtureDriver())
        try:
            worker = await runtime.ensure_worker("demo", str(root), keep_running=True)
            events = asyncio.Queue(maxsize=16)
            worker.subscribers.add(events)
            await runtime.start()
            await runtime.command("demo", {"type": "user_message", "request_id": "fixture-1", "text": "hello"})
            observed = []
            while True:
                event = await asyncio.wait_for(events.get(), timeout=5)
                observed.append(event)
                if event.get("type") == "turn_done":
                    break
            result = {"ok": True, "events": observed,
                      "command_state": runtime.store.commands("demo", "completed")[0]["state"]}
        finally:
            await runtime.close()
        return {**result, "workers_after_close": len(runtime.workers)}


async def _worker(port: int) -> None:
    from http import HTTPStatus

    from websockets.asyncio.server import serve
    from websockets.datastructures import Headers
    from websockets.http11 import Response

    token = os.environ["FIXTURE_TOKEN"]

    def reply(status, payload):
        body = json.dumps(payload).encode()
        return Response(status, HTTPStatus(status).phrase,
                        Headers({"Content-Type": "application/json", "Content-Length": str(len(body))}), body)

    async def authenticate(connection, request):
        if request.headers.get("Authorization") != "Bearer " + token:
            return reply(401, {"error": "unauthorized"})
        if request.path == "/health":
            return reply(200, {"ok": True, "protocol_version": 1})
        if request.path != "/events":
            return reply(404, {"error": "unknown route"})
        return None

    async def handle(socket):
        async for raw in socket:
            command = json.loads(raw)
            if command.get("type") == "user_message":
                await socket.send(json.dumps({"type": "message", "text": "fixture:" + command.get("text", ""),
                                              "request_id": command.get("request_id")}))
                await socket.send(json.dumps({"type": "turn_done", "request_id": command.get("request_id")}))

    async with serve(handle, "127.0.0.1", port, process_request=authenticate):
        await asyncio.Future()


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="Deterministic runtime fixture")
    parser.add_argument("--worker", action="store_true")
    parser.add_argument("--port", type=int)
    args = parser.parse_args()
    if args.worker:
        if args.port is None:
            parser.error("--worker requires --port")
        asyncio.run(_worker(args.port))
    else:
        print(json.dumps(asyncio.run(demo()), indent=2))
