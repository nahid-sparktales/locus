"""Runtime-internal protocol and explicit host ports (wire protocol version 1)."""
from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Mapping, Protocol

TURN_COMMANDS = {"user_message", "retry_last", "evaluation_run"}
DECISION_EVENTS = {"permission_request", "question_required", "dispatch_plan_ready", "mcp_input_request"}
NATIVE_EVENTS = {"computer_action_request", "browser_action_request", "simulator_action_request", "notes_action_request", "calendar_action_request", "board_action_request", "identity_context_request", "identity_action_request"}


@dataclass(frozen=True)
class WorkerLaunchRequest:
    session_id: str
    workspace: str
    root: Path
    port: int
    token: str
    broker_port: int
    broker_token: str
    parent_pid: int


@dataclass(frozen=True)
class WorkerRequest:
    method: str
    path: str
    body: dict | None = None


@dataclass(frozen=True)
class WorkerLaunch:
    # A driver is trusted, installed host code. No command/import strings are
    # accepted from a remote controller or persisted worker record.
    argv: tuple[str, ...]
    environment: Mapping[str, str]
    cwd: str | None = None
    headers: Mapping[str, str] = field(default_factory=dict)
    health_path: str = "/health"
    websocket_path: str = "/events"
    resume: WorkerRequest | None = None
    configuration_paths: frozenset[str] = frozenset()


class WorkerDriver(Protocol):
    def prepare(self, request: WorkerLaunchRequest) -> WorkerLaunch: ...
    def command_request(self, command: dict) -> WorkerRequest | None: ...


class Continuation(Protocol):
    async def tick(self) -> None: ...
    async def close(self) -> None: ...


class ConnectorBroker(Protocol):
    def capabilities(self) -> list[dict]: ...
    async def action(self, event: dict) -> dict: ...


class RemoteConnections(Protocol):
    tunnels: dict
    login_tunnels: dict
    def close(self) -> None: ...
    def records(self) -> list[dict]: ...
    def disconnect(self, key: str) -> None: ...
    def request(self, key: str, method: str, path: str, body: dict, *, timeout: float) -> Any: ...


class ProviderProcesses(Protocol):
    async def ensure_ollama(self, address: str) -> Any: ...
    async def close(self) -> None: ...
