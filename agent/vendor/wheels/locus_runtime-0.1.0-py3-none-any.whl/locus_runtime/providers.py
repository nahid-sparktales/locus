"""Supervisor-owned local model helpers; externally managed servers stay external."""
from __future__ import annotations

import asyncio
import contextlib
import ipaddress
import os
import shutil
import signal
import time
from collections.abc import Callable
from pathlib import Path
from urllib.parse import urlsplit

import requests

from .storage import PrivateStore


class RuntimeProviders:
    def __init__(self, private: PrivateStore, *, environment: Callable[[], dict[str, str]]):
        self.private = private
        self.environment = environment
        self.processes = {}
        self.lock = asyncio.Lock()

    @staticmethod
    def local_address(value):
        parsed = urlsplit(value)
        if parsed.scheme != 'http' or parsed.username or parsed.password or parsed.query or parsed.fragment or parsed.path not in {'', '/'}:
            raise ValueError('Automatic Ollama startup requires a plain local HTTP address')
        host = parsed.hostname
        if host != 'localhost' and (not host or not ipaddress.ip_address(host).is_loopback):
            raise ValueError('Automatic Ollama startup requires a loopback address')
        port = parsed.port or 11434
        if not 1024 <= port <= 65535:
            raise ValueError('Ollama needs an unprivileged port')
        return f'http://127.0.0.1:{port}' if host == 'localhost' else f'http://[{host}]:{port}' if ':' in host else f'http://{host}:{port}'

    @staticmethod
    def healthy(address):
        try:
            with requests.Session() as client:
                client.trust_env = False
                return client.get(address + '/api/tags', timeout=2, allow_redirects=False).status_code == 200
        except requests.RequestException:
            return False

    async def ensure_ollama(self, value):
        address = self.local_address(value)
        async with self.lock:
            if await asyncio.to_thread(self.healthy, address):
                return {'ok': True, 'message': 'Ollama is running.', 'owned': address in self.processes}
            process = self.processes.get(address)
            if process is None or process.returncode is not None:
                if process is not None:
                    await self._stop(address)
                candidates = [shutil.which('ollama'), '/opt/homebrew/bin/ollama', '/usr/local/bin/ollama', '/Applications/Ollama.app/Contents/Resources/ollama']
                executable = next((path for path in candidates if path and Path(path).is_file() and os.access(path, os.X_OK)), None)
                if not executable:
                    raise ValueError('Install Ollama on this runtime host, then retry.')
                environment = self.environment()
                environment.update(OLLAMA_HOST=address)
                process = await asyncio.create_subprocess_exec(executable, 'serve', env=environment,
                    stdin=asyncio.subprocess.DEVNULL, stdout=asyncio.subprocess.DEVNULL, stderr=asyncio.subprocess.DEVNULL,
                    start_new_session=os.name == "posix")
                self.processes[address] = process
            try:
                addresses = self.private.read().get('ollama_hosts', [])
                self.private.set('ollama_hosts', sorted(set(addresses + [address])))
                for _ in range(80):
                    if process.returncode is not None:
                        raise ValueError('The runtime could not start Ollama. Inspect the host installation.')
                    if await asyncio.to_thread(self.healthy, address):
                        return {'ok': True, 'message': 'The independent runtime started Ollama.', 'owned': True}
                    await asyncio.sleep(.25)
                raise ValueError('Ollama did not become ready on the runtime host.')
            except BaseException:
                await self._stop(address)
                raise

    async def _stop(self, address: str) -> None:
        process = self.processes.pop(address, None)
        if process is None:
            return
        def owns_group():
            if process.returncode is None:
                return True
            # asyncio has reaped our leader. If its PID exists again, it is a
            # different process; a cached numeric PGID is no longer authority.
            try:
                os.getpgid(process.pid)
            except ProcessLookupError:
                return True
            except PermissionError:
                return False
            return False
        def signal_owned(force=False):
            with contextlib.suppress(ProcessLookupError):
                if os.name == "posix" and owns_group():
                    os.killpg(process.pid, signal.SIGKILL if force else signal.SIGTERM)
                elif process.returncode is None:
                    (process.kill if force else process.terminate)()
        signal_owned()
        deadline = time.monotonic() + 3
        try:
            await asyncio.wait_for(process.wait(), timeout=3)
        except asyncio.TimeoutError:
            signal_owned(force=True)
            await process.wait()
        if os.name == "posix":
            # A exited parent does not prove its model-server descendants exited.
            while time.monotonic() < deadline:
                if not owns_group():
                    break
                try:
                    os.killpg(process.pid, 0)
                except ProcessLookupError:
                    break
                await asyncio.sleep(.05)
            else:
                signal_owned(force=True)

    async def close(self):
        for address in list(self.processes):
            await self._stop(address)
