"""Execution infrastructure for trusted host applications. Imports have no side effects."""

__version__ = "0.1.0"
PROTOCOL_VERSION = 1
