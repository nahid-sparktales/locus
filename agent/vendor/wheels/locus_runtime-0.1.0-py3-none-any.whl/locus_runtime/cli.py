"""Single console owner, standalone checks, and a fixed trusted host registration."""
from __future__ import annotations

import argparse
import asyncio
import contextlib
import json
import platform
import shutil
import sqlite3
import subprocess
import sys
from importlib import import_module, metadata
from pathlib import Path

from . import PROTOCOL_VERSION, __version__


def _host_entry_point():
    matches = list(metadata.entry_points(group="locus_runtime.host", name="locus"))
    if not matches:
        raise RuntimeError("The Locus host is not installed. Install the composed Locus distribution, or use 'locus-runtime demo'.")
    if len(matches) != 1:
        raise RuntimeError("Ambiguous Locus host registration; reinstall the composed distribution.")
    entry = matches[0]
    owner = (entry.dist.metadata.get("Name", "") if entry.dist else "").lower().replace("_", "-")
    if owner != "ollama-code" or entry.value != "ollama_code.runtime_host:main":
        raise RuntimeError("Untrusted Locus host registration; reinstall the composed distribution.")
    return entry


def doctor(home: Path | None = None, *, database: Path | None = None, host: str | None = None) -> dict:
    """Read-only local inspection. No service start, enrollment, or network probes."""
    checks = [{"name": "runtime", "status": "ok", "version": __version__,
               "protocol_version": PROTOCOL_VERSION, "python": sys.version.split()[0]}]
    for package in ("requests", "websockets"):
        try:
            version = metadata.version(package)
            import_module(package)
            checks.append({"name": package, "status": "ok", "version": version})
        except (metadata.PackageNotFoundError, ImportError, OSError):
            checks.append({"name": package, "status": "error", "message": "Reinstall locus-runtime with its dependencies."})
    try:
        _host_entry_point()
        checks.append({"name": "locus_host", "status": "ok", "message": "Trusted host registration is installed; service readiness is not probed."})
    except RuntimeError as exc:
        checks.append({"name": "locus_host", "status": "unavailable", "message": str(exc)})
    checks.append({"name": "platform", "status": "ok" if (platform.system(), platform.machine().lower()) in {
        ("Linux", "x86_64"), ("Linux", "aarch64"), ("Linux", "arm64"), ("Darwin", "arm64")
    } else "unsupported", "message": f"{platform.system()} {platform.machine()}; composed targets are Linux x86-64/ARM64 and macOS ARM64."})
    checks.append({"name": "ssh", "status": "ok" if shutil.which("ssh") else "unavailable",
                   "message": "OpenSSH is available; host configuration/authentication is unverified." if shutil.which("ssh") else "Install OpenSSH to use an explicitly selected remote host."})
    if home is not None:
        if home.is_symlink() or not home.is_dir() or home.stat().st_mode & 0o077:
            checks.append({"name": "profile", "status": "error", "message": "Select an existing user-only profile directory that is not a symlink."})
        else:
            checks.append({"name": "profile", "status": "ok"})
            recovery = (home / "installation.json").exists()
            checks.append({"name": "installation", "status": "error" if recovery else "ok",
                           "message": "Installation recovery is pending; use the reviewed installer recovery flow." if recovery else "No pending installation journal."})
            credentials = home / "runtime-secrets.json"
            if credentials.exists() or credentials.is_symlink():
                unsafe = credentials.is_symlink() or not credentials.is_file() or credentials.stat().st_mode & 0o077
                checks.append({"name": "private_store", "status": "error" if unsafe else "ok",
                               "message": "Credentials must be a user-only regular file." if unsafe else "Private file permissions are valid; credentials were not read."})
    for name, message in {
        "service_registration": "Registration and operating-system grants require the host-specific service checks.",
        "worker_readiness": "No live worker was inspected.",
        "controller_native_broker": "Controller presence and native grants require the host's capability check.",
        "provider_accounts": "Account selection and credentials require the host's account check; no model call was made.",
    }.items():
        checks.append({"name": name, "status": "unverified", "message": message})
    if host is not None:
        if home is None or database is None:
            checks.append({"name": "remote_selection", "status": "error", "message": "Select --home and --database together with the saved connection ID in --host."})
        elif any(row["status"] == "error" for row in checks):
            checks.append({"name": "remote_selection", "status": "error", "message": "Resolve local profile errors before probing the selected connection."})
        else:
            checks.extend(_probe_selected_host(home, database, host))
    else:
        checks.append({"name": "remote_selection", "status": "unverified", "message": "No network checks were made. Select --home PATH --database PATH --host SAVED_CONNECTION_ID to probe one configured host."})
    return {"ok": not any(check["status"] == "error" for check in checks), "checks": checks}


def _probe_selected_host(home: Path, database: Path, key: str) -> list[dict]:
    """Read existing state only; a diagnostic must never initialize a database."""
    from .remote import RemoteRuntimes, ssh_arguments
    from .storage import PrivateStore

    if database.is_symlink() or not database.is_file() or database.stat().st_mode & 0o077:
        return [{"name": "remote_selection", "status": "error", "message": "Select an existing user-only database that is not a symlink."}]
    try:
        with contextlib.closing(sqlite3.connect(database.resolve().as_uri() + "?mode=ro", uri=True)) as db:
            row = db.execute("SELECT payload FROM runtime_deployments WHERE id=?", (key,)).fetchone()
        if row is None:
            raise ValueError("Unknown saved connection")
        record = json.loads(row[0])
        args = ssh_arguments(record["host"])
        if record.get("id") != key or not isinstance(record.get("port"), int) or not 1024 <= record["port"] <= 65535:
            raise ValueError("Invalid saved connection")
        private = PrivateStore(home)
        if not (private.read().get(f"remote:{key}") or {}).get("token"):
            return [{"name": "remote_authentication", "status": "error", "message": "The saved connection has no runtime credential; reconnect through the host's reviewed setup."}]
    except (OSError, sqlite3.Error, ValueError, KeyError, TypeError):
        return [{"name": "remote_selection", "status": "error", "message": "The saved connection could not be read. Select its existing runtime database and profile."}]
    try:
        probe = subprocess.run(args + ["true"], capture_output=True, timeout=15)
    except FileNotFoundError:
        return [{"name": "ssh_binary", "status": "error", "message": "OpenSSH is unavailable."}]
    except (OSError, subprocess.TimeoutExpired):
        return [{"name": "ssh_reachability", "status": "error", "message": "The selected host could not be reached within 15 seconds; check its address and connectivity."}]
    if probe.returncode:
        error = probe.stderr.decode(errors="replace").lower()
        if "host key" in error or "host identification has changed" in error:
            name, message = "ssh_host_key", "Verify the selected host's key through your existing OpenSSH trust workflow. No trust settings were changed."
        elif "permission denied" in error or "authentication failed" in error:
            name, message = "ssh_authentication", "Existing SSH authentication was rejected. Check the selected host's configured user/key."
        elif "bad configuration" in error or "bad configuration option" in error:
            name, message = "ssh_configuration", "OpenSSH rejected its configuration. Check the selected host entry."
        else:
            name, message = "ssh_reachability", "The selected host was unreachable; check its saved alias and connectivity."
        return [{"name": name, "status": "error", "message": message}]

    class SelectedStore:
        def deployments(self):
            return [record]

    remotes = RemoteRuntimes(SelectedStore(), private, home)
    checks = [{"name": "ssh_authentication", "status": "ok", "message": "The selected host accepted existing SSH authentication and host-key verification."}]
    try:
        remotes.connect(key)
        checks.append({"name": "tunnel", "status": "ok", "message": "A temporary loopback tunnel opened; service health is checked separately."})
        status = remotes.request(key, "GET", "/api/runtime", timeout=10)
        if status.get("protocol_version") != PROTOCOL_VERSION:
            checks.append({"name": "protocol", "status": "error", "message": "Upgrade required: the remote runtime protocol is incompatible."})
        elif record.get("runtime_id") and status.get("id") != record["runtime_id"]:
            checks.append({"name": "runtime_identity", "status": "error", "message": "The remote identity changed; review and explicitly reconnect in the host application."})
        elif status.get("independent") is not True or status.get("connected") is not True:
            checks.append({"name": "service", "status": "error", "message": "The authenticated response did not confirm an independent runtime service."})
        else:
            checks.append({"name": "service", "status": "ok", "message": "Authenticated runtime service and protocol are ready."})
            states = {}
            for worker in status.get("workers", []):
                state = worker.get("state")
                if state in {"idle", "queued", "running", "paused", "completed", "interrupted", "uncertain", "waiting_approval", "waiting_for_locus", "waiting_for_account"}:
                    states[state] = states.get(state, 0) + 1
            checks.append({"name": "work", "status": "observed", "states": states,
                           "message": "Reported work states; readiness of a new worker remains unverified."})
            if status.get("maintenance"):
                checks.append({"name": "remote_installation", "status": "error", "message": "Remote installation recovery or maintenance is pending; use the reviewed recovery flow."})
    except (ValueError, OSError, KeyError, TypeError):
        checks.append({"name": "service" if any(row["name"] == "tunnel" for row in checks) else "tunnel", "status": "error", "message": "The selected connection did not provide authenticated runtime health. Check the saved credential and remote service; its work may still be running."})
    finally:
        remotes.close()
    return checks


def main(argv: list[str] | None = None) -> None:
    arguments = list(sys.argv[1:] if argv is None else argv)
    if arguments and arguments[0] == "doctor":
        parser = argparse.ArgumentParser(description="Read-only local runtime diagnostics")
        parser.add_argument("--home", type=Path)
        parser.add_argument("--json", action="store_true", help="Emit structured JSON")
        parser.add_argument("--database", type=Path, help="Existing runtime state database, read-only")
        parser.add_argument("--host", help="Explicit saved connection ID; enables a probe of only that configured host")
        args = parser.parse_args(arguments[1:])
        result = doctor(args.home, database=args.database, host=args.host)
        if args.json:
            print(json.dumps(result, indent=2))
        else:
            for check in result["checks"]:
                detail = check.get("message") or check.get("version") or ""
                if "states" in check:
                    detail += " " + json.dumps(check["states"], sort_keys=True)
                print(f"{check['status'].upper():11} {check['name']}: {detail}")
        if not result["ok"]:
            raise SystemExit(1)
        return
    if arguments and arguments[0] == "demo":
        parser = argparse.ArgumentParser(description="Run a harmless temporary worker with no Locus installation")
        parser.parse_args(arguments[1:])
        from .standalone import demo
        print(json.dumps(asyncio.run(demo()), indent=2))
        return
    if not arguments or arguments in (["--help"], ["-h"]):
        parser = argparse.ArgumentParser(description="Independent execution runtime. Commands: doctor [--home PATH], demo. Legacy Locus service arguments use the fixed installed Locus host.")
        parser.add_argument("--home", help="Locus service profile directory")
        parser.add_argument("--port", type=int, default=8793)
        parser.add_argument("--cwd", help="Locus service workspace")
        parser.print_help()
        return
    try:
        entry = _host_entry_point()
    except RuntimeError as exc:
        raise SystemExit(str(exc)) from None
    entry.load()(arguments)


if __name__ == "__main__":
    main()
