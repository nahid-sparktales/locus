"""Independent worker supervisor. The desktop is a replaceable controller.

Extracted and adapted from Locus; source revision and changes are in NOTICE.
"""
from __future__ import annotations

import asyncio
import contextlib
import hashlib
import hmac
import json
import os
import secrets
import signal
import socket
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable, Mapping

import requests
from websockets.asyncio.client import connect

from .contracts import (
    DECISION_EVENTS,
    NATIVE_EVENTS,
    TURN_COMMANDS,
    ConnectorBroker,
    Continuation,
    ProviderProcesses,
    RemoteConnections,
    WorkerDriver,
    WorkerLaunchRequest,
)
from .storage import PrivateStore, RuntimeStore, identifier


@dataclass
class Worker:
    session_id: str
    process: asyncio.subprocess.Process
    port: int
    token: str
    ws: Any = None
    pump: asyncio.Task | None = None
    log_task: asyncio.Task | None = None
    subscribers: set = field(default_factory=set)
    active_command: str = ""
    last_controller: float = 0
    session_info: dict = field(default_factory=dict)
    send_lock: asyncio.Lock = field(default_factory=asyncio.Lock)
    headers: dict = field(default_factory=dict)
    configuration_paths: frozenset[str] = frozenset()
    # Set only for a fresh child launched in a new session, never from a stored PID.
    process_group: int | None = None


class RuntimeSupervisor:
    def __init__(self, root: Path, *, store: RuntimeStore, private: PrivateStore,
                 driver: WorkerDriver, port: int = 8793, limit: int = 2,
                 remotes: RemoteConnections | None = None,
                 providers: ProviderProcesses | None = None,
                 continuation: Continuation | None = None,
                 connectors: ConnectorBroker | None = None,
                 recover: Callable[[], None] | None = None,
                 event_sink: Callable[[dict], None] | None = None,
                 capabilities: Mapping[str, bool] | None = None,
                 package_id: str = ""):
        self.store = store
        self.private = private
        self.driver = driver
        self.root = root
        self.port = port
        self.limit = max(1, min(limit, 4))
        self.workers: dict[str, Worker] = {}
        self.launch_lock = asyncio.Lock()
        self.coordinator: asyncio.Task | None = None
        self.controller_seen = 0.0
        self.direct_controller_seen = 0.0
        self.remote_heartbeat_at = 0.0
        self.remote_heartbeats = {}
        self.remotes = remotes
        self.stopping = False
        self.automation = continuation
        self.connectors = connectors
        self.providers = providers
        self.recover = recover
        self.event_sink = event_sink
        self.capabilities = dict(capabilities or {})
        self.paused = self.maintenance or bool(self.private.read().get("paused", False))
        identity = self.private.read().get("runtime_id") or secrets.token_hex(16)
        self.private.set("runtime_id", identity)
        self.runtime_id = identity
        self.package_id = package_id or "locus-runtime/0.1.0"

    @property
    def maintenance(self) -> bool:
        return (self.root / "installation.json").exists()

    async def start(self) -> None:
        if self.recover:
            self.recover()
        # A prior process's sent work has an uncertain outcome. Never replay it.
        for row in self.store.workers():
            if row["state"] not in {"idle", "paused", "completed"} or self.store.commands(row["session_id"], "sent"):
                self.store.interrupted(row["session_id"])
        for address in self.private.read().get("ollama_hosts", []) if self.providers else []:
            try:
                await self.providers.ensure_ollama(address)
            except (ValueError, OSError):
                self.store.append("runtime", {"type": "provider_unavailable", "message": "Ollama could not restart; check the runtime host."})
        self.coordinator = asyncio.create_task(self.coordinate())

    async def close(self) -> None:
        self.stopping = True
        if self.coordinator:
            self.coordinator.cancel()
            with contextlib.suppress(asyncio.CancelledError):
                await self.coordinator
        if self.automation:
            await self.automation.close()
        heartbeats = list(self.remote_heartbeats.values())
        for heartbeat in heartbeats:
            heartbeat.cancel()
        if heartbeats:
            await asyncio.gather(*heartbeats, return_exceptions=True)
        self.remote_heartbeats.clear()
        if self.remotes is not None:
            self.remotes.close()
        for worker in list(self.workers.values()):
            if worker.active_command:
                with contextlib.suppress(Exception):
                    await self.send(worker, {"type": "interrupt", "reason": "app_shutdown"})
        deadline = time.monotonic() + 4
        while any(worker.active_command for worker in self.workers.values()) and time.monotonic() < deadline:
            await asyncio.sleep(.1)
        await asyncio.gather(*(self.stop_worker(key) for key in list(self.workers)), return_exceptions=True)
        if self.providers is not None:
            await self.providers.close()

    def status(self) -> dict:
        return {"id": self.runtime_id, "version": 1, "protocol_version": 1,
                "independent": True, "connected": True, "paused": self.paused, "maintenance": self.maintenance, "package_id": self.package_id, "workers": self.store.workers(),
                "pending_approvals": self.store.decisions(), "max_active_chats": self.limit,
                "active_work": sum(bool(worker.active_command) for worker in self.workers.values()),
                "capabilities": {"durable_events": True, "desktop_requires_controller": True,
                                 **self.capabilities}}

    async def ensure_worker(self, session_id: str, workspace: str, *, keep_running: bool | None = None) -> Worker:
        if self.maintenance:
            raise RuntimeError("Runtime installation is in progress; retry when it is ready")
        identifier(session_id)
        async with self.launch_lock:
            record = self.store.save_worker(session_id, workspace, keep_running=keep_running)
            existing = self.workers.get(session_id)
            if existing and existing.process.returncode is None:
                return existing
            if existing:
                await self.stop_worker(session_id)
            with socket.socket() as reservation:
                reservation.bind(("127.0.0.1", 0))
                port = reservation.getsockname()[1]
            token = secrets.token_hex(32)
            launch = self.driver.prepare(WorkerLaunchRequest(
                session_id, workspace, self.root, port, token, self.port,
                self.private.token(), os.getpid()))
            process = await asyncio.create_subprocess_exec(
                *launch.argv, env=dict(launch.environment), cwd=launch.cwd,
                stdin=asyncio.subprocess.DEVNULL, stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.STDOUT, start_new_session=os.name == "posix")
            worker = Worker(session_id, process, port, token)
            worker.headers = dict(launch.headers)
            worker.configuration_paths = launch.configuration_paths
            worker.process_group = process.pid if os.name == "posix" else None
            self.workers[session_id] = worker
            # Always drain child output; provider errors may include secrets, so
            # raw child output is deliberately not exported as a runtime event.
            worker.log_task = asyncio.create_task(self._drain(worker))
            try:
                for _ in range(120):
                    if process.returncode is not None:
                        raise RuntimeError("The agent process exited during startup")
                    try:
                        await self.request(worker, "GET", launch.health_path, timeout=1)
                        break
                    except (requests.RequestException, RuntimeError):
                        await asyncio.sleep(0.25)
                else:
                    raise RuntimeError("The agent did not become ready")
                saved = self.private.read().get(f"worker:{session_id}", {})
                for path, body in saved.items():
                    if path in worker.configuration_paths:
                        await self.request(worker, "POST", path, body)
                if launch.resume:
                    resumed = await self.request(worker, launch.resume.method, launch.resume.path, launch.resume.body)
                    worker.session_info = resumed.get("session_info", {})
                worker.ws = await connect(f"ws://127.0.0.1:{port}{launch.websocket_path}",
                                          additional_headers=worker.headers, max_size=4*1024*1024)
                worker.pump = asyncio.create_task(self._pump(worker))
                await self.connector_capabilities(worker)
                self.store.state(session_id, record["state"] if record["state"] in {"interrupted", "paused"} else "idle")
                return worker
            except BaseException:
                await self.stop_worker(session_id)
                raise

    async def _drain(self, worker: Worker) -> None:
        if worker.process.stdout:
            while await worker.process.stdout.read(65536):
                pass

    async def request(self, worker: Worker, method: str, path: str, body=None, *, timeout=30) -> dict:
        def invoke():
            with requests.Session() as client:
                client.trust_env = False
                response = client.request(method, f"http://127.0.0.1:{worker.port}{path}",
                                          headers=worker.headers, json=body,
                                          timeout=timeout, allow_redirects=False)
                if response.status_code >= 400:
                    error = RuntimeError(response.text[:2000])
                    error.status_code = response.status_code
                    raise error
                return response.json() if response.content else {}
        result = await asyncio.to_thread(invoke)
        if method in {"POST", "PUT", "PATCH"} and path in worker.configuration_paths:
            saved = self.private.read().get(f"worker:{worker.session_id}", {})
            saved[path] = {**saved.get(path, {}), **(body or {})}
            self.private.set(f"worker:{worker.session_id}", saved)
        return result

    async def send(self, worker: Worker, message: dict) -> None:
        async with worker.send_lock:
            if worker.ws is None:
                raise RuntimeError("The agent is disconnected")
            await worker.ws.send(json.dumps(message))

    async def command(self, session_id: str, message: dict) -> dict:
        if self.maintenance:
            raise RuntimeError("Runtime installation is in progress; retry when it is ready")
        worker = self.workers.get(session_id)
        if not worker:
            row = self.store.worker(session_id)
            if not row:
                raise ValueError("Unknown runtime session")
            worker = await self.ensure_worker(session_id, row["workspace"])
        if message.get("type") in {"set_computer_control", "set_browser_control", "set_simulator_control", "set_notes_control", "set_calendar_control", "set_board_control", "set_identity_control"}:
            message = {**message, "runtime_broker": True}
        control = self.driver.command_request(message) if message.get("type") not in TURN_COMMANDS else None
        if control:
            await self.request(worker, control.method, control.path, control.body)
            return {"ok": True}
        if message.get("type") in TURN_COMMANDS:
            key = self.enqueue(session_id, message)
            return {"ok": True, "state": "queued", "request_id": key}
        if message.get("type") in {"permission_decision", "question_response", "dispatch_decision", "mcp_input_response"} | {kind.replace("request", "result") for kind in NATIVE_EVENTS}:
            decision = message.pop("runtime_decision", {})
            await self.resolve(str(decision.get("id", "")), str(decision.get("fingerprint", "")), message)
        elif message.get("type") == "set_connector_control":
            await self.connector_capabilities(worker)
        else:
            await self.send(worker, message)
        return {"ok": True}

    def enqueue(self, session_id: str, message: dict) -> str:
        message = dict(message)
        message.setdefault("request_id", message.get("run_id") or secrets.token_hex(16))
        message.pop("_runtime_command_fingerprint", None)
        # A keyed digest binds the full private payload without exposing secrets
        # or allowing offline guesses against low-entropy configuration values.
        fingerprint = hmac.new(self.private.token().encode(),
                               json.dumps(message, sort_keys=True).encode(), hashlib.sha256).hexdigest()
        public = {**self.store.sanitize(message), "_runtime_command_fingerprint": fingerprint}
        previous = self.private.read().get(f"command:{message['request_id']}")
        key = self.store.enqueue(session_id, public, legacy_payload_verified=previous == message)
        self.private.set(f"command:{key}", message)
        return key

    def restore_decision_event(self, event):
        decision = event.get("runtime_decision") or {}
        if decision.get("id") and event.get("type") in DECISION_EVENTS | NATIVE_EVENTS:
            if self.store.decision_state(decision["id"]) != "waiting":
                return {"type": "runtime_cursor", "runtime_seq": event.get("runtime_seq", 0), "runtime_session_id": event.get("runtime_session_id", "")}
            original = self.private.read().get("decision:" + decision["id"])
            if original:
                return {**event, **original, "runtime_decision": decision}
        return event

    async def publish(self, worker: Worker, event: dict) -> None:
        durable = self.store.append(worker.session_id, event)
        for subscriber in tuple(worker.subscribers):
            try:
                subscriber.put_nowait(durable)
            except asyncio.QueueFull:
                # The client reconnects from its acknowledged cursor.
                worker.subscribers.discard(subscriber)
                while not subscriber.empty():
                    subscriber.get_nowait()
                subscriber.put_nowait({"type": "runtime_resync_required"})

    async def _pump(self, worker: Worker) -> None:
        try:
            async for raw in worker.ws:
                event = json.loads(raw)
                kind = event.get("type")
                if kind == "session_info":
                    worker.session_info = event
                if kind == "runtime_waiting_for_locus":
                    self.store.state(worker.session_id, "waiting_for_locus", event.get("reason", "Desktop capability unavailable"))
                elif kind == "runtime_capability_ready":
                    self.store.state(worker.session_id, "running" if worker.active_command else "idle")
                if kind in DECISION_EVENTS | NATIVE_EVENTS:
                    decision = self.store.decision(worker.session_id, event)
                    self.private.set("decision:" + decision["id"], event)
                    event["runtime_decision"] = {"id": decision["id"], "fingerprint": decision["fingerprint"]}
                    self.store.state(worker.session_id, "waiting_for_locus" if kind in NATIVE_EVENTS else "waiting_approval", "Locus is needed for " + str(event.get("tool") or kind) if kind in NATIVE_EVENTS else "Awaiting your decision")
                if self.event_sink:
                    self.event_sink(event)
                if kind in {"turn_done", "evaluation_completed"}:
                    if worker.active_command:
                        self.store.command_state(worker.active_command, "completed")
                    worker.active_command = ""
                    if self.store.worker(worker.session_id)["state"] != "paused":
                        self.store.state(worker.session_id, "idle")
                if kind == "connector_action_request":
                    await self._connector_action(worker, event)
                    # Only the service performs connector actions. Never ask the desktop twice.
                    continue
                await self.publish(worker, event)
        except asyncio.CancelledError:
            raise
        except Exception:
            pass
        finally:
            if not self.stopping and self.workers.get(worker.session_id) is worker:
                self.store.interrupted(worker.session_id)
                await self.publish(worker, {"type": "runtime_worker_interrupted", "message": "The worker stopped. Review saved progress before resuming."})

    async def connector_capabilities(self, worker: Worker) -> None:
        connections = self.connectors.capabilities() if self.connectors else []
        await self.send(worker, {"type": "set_connector_control", "capability": {"protocol_version": 1, "connections": connections}})

    async def controller_left(self, worker: Worker) -> None:
        if worker.subscribers:
            return
        self.store.broker_left(worker.session_id)
        await self.send(worker, {"type": "runtime_desktop_disconnected", "runtime_broker": True})
        record = self.store.worker(worker.session_id)
        if record and not record["keep_running"]:
            self.store.state(worker.session_id, "paused")
            if worker.active_command:
                await self.send(worker, {"type": "interrupt", "reason": "app_shutdown"})

    async def _connector_action(self, worker: Worker, event: dict) -> None:
        # Persist the intent before an external effect. An interrupted receipt is
        # uncertain, never an invitation to resend a message or repeat a write.
        action_id = str(event.get("idempotency_key") or event.get("request_id") or "")
        receipt = self.store.action_receipt(worker.session_id, action_id)
        if receipt:
            result = receipt.get("result") or {"error": "This external action has an uncertain outcome; review it before retrying."}
        else:
            self.store.append(worker.session_id, {"type": "connector_action_intent", "action_id": action_id})
            result = await self.connectors.action(event) if self.connectors else {"error": "No connector broker is available on this host."}
            self.store.append(worker.session_id, {"type": "connector_action_receipt", "action_id": action_id, "result": result})
        await self.send(worker, {"type": "connector_action_result", "request_id": event.get("request_id"), "result": result})

    async def resolve(self, key: str, fingerprint: str, response: dict) -> None:
        decisions = [row for row in self.store.decisions(include_inflight=True) if row["id"] == key]
        if not decisions:
            raise ValueError("This decision is no longer current")
        event = decisions[0]["event"]
        expected = {"permission_request": "permission_decision", "question_required": "question_response", "dispatch_plan_ready": "dispatch_decision", "mcp_input_request": "mcp_input_response"}.get(event["type"], event["type"].replace("request", "result"))
        identity_field = "run_id" if expected == "dispatch_decision" else "request_id"
        if response.get("type") != expected or response.get(identity_field) != event.get(identity_field):
            raise ValueError("This response does not match the pending decision")
        session_id = self.store.resolve(key, fingerprint, response)
        worker = self.workers.get(session_id)
        if not worker or worker.process.returncode is not None:
            self.store.interrupted(session_id)
            raise ValueError("The worker stopped; review the interrupted action before resuming")
        await self.send(worker, response)
        self.store.complete_decision(key)
        self.private.set("decision:" + key, None)
        self.store.state(session_id, "running" if worker.active_command else "idle")

    async def stop_worker(self, session_id: str) -> None:
        worker = self.workers.pop(session_id, None)
        if not worker:
            return
        if worker.pump:
            worker.pump.cancel()
            with contextlib.suppress(asyncio.CancelledError):
                await worker.pump
        if worker.ws:
            with contextlib.suppress(Exception):
                await asyncio.wait_for(worker.ws.close(), timeout=5)

        def owned_group():
            if worker.process_group is not None and worker.process.returncode is not None:
                # asyncio has reaped the original leader. If this numeric PID
                # exists again it belongs to a different process, so discard
                # the stale group instead of signaling an unrelated owner.
                try:
                    os.getpgid(worker.process.pid)
                except ProcessLookupError:
                    pass
                else:
                    worker.process_group = None
            return worker.process_group

        def stop_owned(force=False):
            # Only the in-memory group created by this supervisor is eligible.
            # Descendants can retain the output pipe after the leader exits.
            with contextlib.suppress(ProcessLookupError):
                group = owned_group() if os.name == "posix" else None
                if group is not None:
                    os.killpg(group, signal.SIGKILL if force else signal.SIGTERM)
                elif worker.process.returncode is None:
                    (worker.process.kill if force else worker.process.terminate)()

        deadline = time.monotonic() + 5
        stop_owned()
        try:
            pending = [worker.process.wait()]
            if worker.log_task:
                pending.append(asyncio.shield(worker.log_task))
            await asyncio.wait_for(asyncio.gather(*pending), timeout=5)
            # A descendant may close both output pipes and ignore TERM. The
            # leader/log tasks finishing is not proof the owned group exited.
            if worker.process_group is not None and os.name == "posix":
                while time.monotonic() < deadline:
                    group = owned_group()
                    if group is None:
                        break
                    try:
                        os.killpg(group, 0)
                    except ProcessLookupError:
                        break
                    await asyncio.sleep(.05)
                else:
                    stop_owned(force=True)
        except asyncio.TimeoutError:
            stop_owned(force=True)
            await asyncio.wait_for(worker.process.wait(), timeout=5)
        finally:
            worker.process_group = None
        if worker.active_command:
            self.store.interrupted(session_id)
        if worker.log_task:
            try:
                await asyncio.wait_for(worker.log_task, timeout=1)
            except (asyncio.TimeoutError, asyncio.CancelledError):
                pass

    async def detach(self) -> None:
        was_direct = bool(self.direct_controller_seen)
        self.controller_seen = 0
        self.direct_controller_seen = 0
        for session_id, worker in list(self.workers.items()):
            self.store.broker_left(session_id)
            await self.send(worker, {"type": "runtime_desktop_disconnected", "runtime_broker": True})
            record = self.store.worker(session_id)
            if not record or not record["keep_running"]:
                if worker.active_command:
                    await self.send(worker, {"type": "interrupt", "reason": "app_shutdown"})
                self.store.state(session_id, "paused")
        if was_direct and self.remotes is not None:
            async def disconnect_remote(key):
                with contextlib.suppress(Exception):
                    await asyncio.to_thread(self.remotes.request, key, "POST", "/api/runtime/detach", {}, timeout=5)
            await asyncio.gather(*(disconnect_remote(row["id"]) for row in self.remotes.records()))

    def relay_controller_presence(self):
        now = time.monotonic()
        if self.remotes is None:
            return
        if not self.direct_controller_seen or now - self.direct_controller_seen > 35 or now - self.remote_heartbeat_at < 15:
            return
        self.remote_heartbeat_at = now
        async def heartbeat(key):
            with contextlib.suppress(Exception):
                await asyncio.to_thread(self.remotes.request, key, "POST", "/api/runtime/heartbeat", {"relayed": True}, timeout=5)
        for row in self.remotes.records():
            prior = self.remote_heartbeats.get(row["id"])
            if prior is None or prior.done():
                self.remote_heartbeats[row["id"]] = asyncio.create_task(heartbeat(row["id"]))

    async def coordinate(self) -> None:
        while True:
            try:
                if self.controller_seen and time.monotonic() - self.controller_seen > 35:
                    await self.detach()
                self.relay_controller_presence()
                if self.paused or self.maintenance:
                    await asyncio.sleep(1)
                    continue
                if self.automation:
                    await self.automation.tick()
                active = sum(bool(worker.active_command) for worker in self.workers.values())
                for record in self.store.workers():
                    if active >= self.limit:
                        break
                    if record["state"] in {"paused", "interrupted", "waiting_for_locus", "waiting_approval", "waiting_for_account"}:
                        continue
                    if not self.controller_seen and not record["keep_running"]:
                        continue
                    commands = self.store.commands(record["session_id"])
                    if not commands:
                        continue
                    worker = await self.ensure_worker(record["session_id"], record["workspace"])
                    if worker.active_command:
                        continue
                    # Conversation workers are independent even when their
                    # project folder is shared. Keep per-chat ordering and the
                    # global limit; worktree selection owns edit isolation.
                    item = commands[0]
                    command = dict(self.private.read().get(f"command:{item['id']}", item["command"]))
                    command.pop("_runtime_command_fingerprint", None)
                    try:
                        for path, body in command.pop("runtime_configuration", {}).items():
                            if path in worker.configuration_paths:
                                await self.request(worker, "POST", path, body)
                    except RuntimeError:
                        self.store.state(worker.session_id, "waiting_for_account", "The selected account or model is unavailable. Review its configuration.")
                        continue
                    self.store.command_state(item["id"], "sent")
                    worker.active_command = item["id"]
                    self.store.state(worker.session_id, "running")
                    operation = self.driver.command_request(command)
                    if operation:
                        await self.request(worker, operation.method, operation.path, operation.body)
                    else:
                        await self.send(worker, command)
                    active += 1
            except asyncio.CancelledError:
                raise
            except Exception as exc:
                self.store.append("runtime", {"type": "runtime_error", "message": str(exc)[:1000]})
            await asyncio.sleep(1)

